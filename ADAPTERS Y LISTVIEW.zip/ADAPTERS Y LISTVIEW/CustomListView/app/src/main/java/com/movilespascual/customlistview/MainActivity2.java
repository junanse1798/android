package com.movilespascual.customlistview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView nombre, horaultimoM, ulmimoM ;
    ImageButton boton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        nombre = findViewById(R.id.nombrePersonaUser);
        horaultimoM = findViewById(R.id.ultimoMensajeUser);
        ulmimoM = findViewById(R.id.horaMensajeUser);

        //recibo datos del intent.  recuperando los extras del MainActivity
        //Intent recibidos = getIntent();
        String name = getIntent().getStringExtra("name");
        String hMessage = getIntent().getStringExtra("hMessage");
        String Umessage = getIntent().getStringExtra("Umessage");

        //Mostrar los datos
        nombre.setText(name);
        horaultimoM.setText(hMessage);
        ulmimoM.setText(Umessage);
        Log.i("ActividadDos","--onCreate--");
    }

    @Override
    protected void onStart() {
        super.onStart();
        //Declarar el boton
        boton = findViewById(R.id.botonAtras);
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent regresar = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(regresar);
            }
        });

        //Log.i(TAG,"onStart");
        //Log.i("ActividadDos", "--onStart--");
    }
}