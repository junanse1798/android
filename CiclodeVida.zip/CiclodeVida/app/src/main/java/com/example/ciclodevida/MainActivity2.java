package com.example.ciclodevida;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView textoUno, textoDos;
    Button boton;
    String TAG = "Boton creado en: ";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
/*        textoUno = findViewById(R.id.textoUnoRecibido);
        textoDos = findViewById(R.id.textoDosRecibido);

        //recibo datos del intent.  recuperando los extras del MainActivity
        //Intent recibidos = getIntent();
        String email = getIntent().getStringExtra("email");
        String password = getIntent().getStringExtra("password");
        //Mostrar los datos
        textoUno.setText(email);
        textoDos.setText(password);
        Log.i("ActividadDos","--onCreate--");*/
    }

    @Override
    protected void onStart() {
        super.onStart();
        //Declarar el boton
        boton = findViewById(R.id.botonAtras);
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent regresar = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(regresar);
            }
        });

        Log.i(TAG,"onStart");
        Log.i("ActividadDos", "--onStart--");
    }
    public void gotoMaps(View view){
        /*ACTION_VIEW
         *Usa esta acción en una intent con startActivity() cuando tengas información que la
         * actividad pueda mostrar al usuario, como una foto para ver en una app de galería
         * o una dirección para ver en una app de mapas.
         * */
        Intent intent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse("geo:41.3825581,2.1704375?z=16&q=41.3825581,2.1704375(Barcelona)"));
        intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");
        startActivity(intent);
    }
}