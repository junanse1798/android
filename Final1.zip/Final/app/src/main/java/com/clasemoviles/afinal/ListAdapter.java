package com.clasemoviles.afinal;

import android.content.Context;
import android.view.LayoutInflater;

public class ListAdapter {
    Context contexto;
    String [] nombres, mensajeUno,mensajeDos;
    int[] idImagen;
    LayoutInflater inflater;

    public ListAdapter(Context contexto, String[] nombres, String[] mensajeUno, String[] mensajeDos, int[] idImagen) {
        this.contexto = contexto;
        this.nombres = nombres;

        this.mensajeUno = mensajeUno;
        this.mensajeDos = mensajeDos;

        this.idImagen = idImagen;
        inflater = LayoutInflater.from(contexto);
    }

    @Override
    public  int getCount(){return nombres.length;}






}
