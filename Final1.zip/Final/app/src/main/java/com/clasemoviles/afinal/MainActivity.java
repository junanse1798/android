package com.clasemoviles.afinal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int[] idImagen = {
                R.drawable.logo_musica1,

        };

        String[] nombre = {
                "Juan Camilo",
                "Jean Paul",
                "Craig",
                "Mike",
                "Ivana",
                "Michelle Molina"
        };

        String[] mensajeuno ={
                "Hey", "What´s Up","Nos vemos hoy?","Qué haces?","Wie heist du?","Gotta go"
        };

        String[] mensajedos ={
                "10:30", "20:50","00:01","03:44","10:45","13:56"
        };
    }
}