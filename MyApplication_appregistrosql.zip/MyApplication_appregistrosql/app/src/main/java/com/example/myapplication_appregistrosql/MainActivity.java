package com.example.myapplication_appregistrosql;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText documento,contraseña, telefono,saldo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contraseña =(EditText)findViewById(R.id.etContraseña);
        documento =(EditText)findViewById(R.id.etDocumento);
        telefono =(EditText)findViewById(R.id.etTelefono);
        saldo =(EditText)findViewById(R.id.etSaldo);
    }

    public void registrar(View view)
    {

        AdminBD admin = new AdminBD(this, "BaseDatos", null,1);
        SQLiteDatabase BaseDatos = admin.getWritableDatabase();
        String document = documento.getText().toString();
        String password =  contraseña.getText().toString();
        String telephone =  telefono.getText().toString();
        String balance = saldo.getText().toString();
        if (!document.isEmpty()){
            Cursor fila  = BaseDatos.rawQuery("select  telefono, saldo from usuarios where cedula ="+document,null);
            if (fila.moveToFirst()){
                String idPersona = fila.getString(0);
                if (!idPersona.isEmpty()){
                    Toast.makeText(this, "El registro ya existe", Toast.LENGTH_SHORT).show();
                }
            }
        }
        else if (!document.isEmpty() && !password.isEmpty() && !telephone.isEmpty() && !balance.isEmpty())
        {
            ContentValues registro = new ContentValues();
            registro.put("documento",document);
            registro.put("contraseña",password);
            registro.put("telefono",telephone);
            registro.put("saldo",balance);

            BaseDatos.insert("usuarios", null,registro);
            BaseDatos.close();
            documento.setText("");
            contraseña.setText("");
            telefono.setText("");
            saldo.setText("");
            Toast.makeText(this,"almacenado exitosamente", Toast.LENGTH_LONG).show();

        }
        else
        {
            Toast.makeText(this,"ingrese correctamente los datos", Toast.LENGTH_LONG).show();
        }

    }
    public void consultar(View view)
    {
        AdminBD admin = new AdminBD(this, "BaseDatos",null,1);
        SQLiteDatabase BaseDatos = admin.getWritableDatabase();
        String document = documento.getText().toString();
        String password =  contraseña.getText().toString();

        if(!document.isEmpty() && !password.isEmpty())
        {

            Cursor fila = BaseDatos.rawQuery("select telefono, saldo from usuarios where documento="+document,null );
            if (fila.moveToFirst())
            {

                telefono.setText(fila.getString(0));
                saldo.setText(fila.getString(1));
                BaseDatos.close();
            }
            else
            {
                Toast.makeText(this,"ususario no encontrado",Toast.LENGTH_LONG).show();
            }
        }
        else
        {
            Toast.makeText(this,"ingrse los datos",Toast.LENGTH_LONG).show();
        }
    }
}