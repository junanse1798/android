package com.example.myapplication_appregistrosql;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText documento,contraseña, telefono,saldo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contraseña =(EditText)findViewById(R.id.etContraseña);
        documento =(EditText)findViewById(R.id.etDocumento);
        telefono =(EditText)findViewById(R.id.etTelefono);
        saldo =(EditText)findViewById(R.id.etSaldo);
    }

    public void registrar(View view)
    {

        AdminBD admin = new AdminBD(this, "BaseDAtos", null,1);
        SQLiteDatabase BaseDAtos = admin.getWritableDatabase();
        int document = Integer.parseInt(documento.getText().toString());
        int password =  Integer.parseInt(contraseña.getText().toString());
        int telephone =  Integer.parseInt(telefono.getText().toString());
        float balance = Float.parseFloat(saldo.getText().toString());

        if (!TextUtils.isEmpty(documento.getText().toString()) &&
                !TextUtils.isEmpty(contraseña.getText().toString()) &&
                !TextUtils.isEmpty(telefono.getText().toString()) &&
                !TextUtils.isEmpty(saldo.getText().toString()))
        {
            ContentValues registro = new ContentValues();
            registro.put("documento",document);
            registro.put("contraseña",password);
            registro.put("telefono",telephone);
            registro.put("saldo",balance);
            BaseDAtos.insert("usuario", null,registro);
            BaseDAtos.close();
            documento.setText("");
            contraseña.setText("");
            telefono.setText("");
            saldo.setText("");
            Toast.makeText(this,"almacenado exitosamente", Toast.LENGTH_LONG).show();

        }
        else
        {
            Toast.makeText(this,"ingrese correctamente los datos", Toast.LENGTH_LONG).show();
        }

    }
    public void consultar(View view)
    {
        AdminBD admin = new AdminBD(this, "BaseDatos",null,1);
        SQLiteDatabase BaseDatos = admin.getWritableDatabase();

        if(!TextUtils.isEmpty(documento.getText().toString()) &&
                !TextUtils.isEmpty(telefono.getText().toString()))
        {
            Cursor fila = BaseDatos.rawQuery("select telefono, saldo from usuario where (documento="+documento+") and (contraseña="+contraseña+")",null );
            if (fila.moveToFirst())
            {

                telefono.setText(fila.getString(0));
                saldo.setText(fila.getString(1));
                BaseDatos.close();
            }
            else
            {
                Toast.makeText(this,"ususario no encontrado",Toast.LENGTH_LONG).show();
            }
        }
    }
}